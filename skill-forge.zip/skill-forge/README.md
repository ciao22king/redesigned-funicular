# Skill Forge

Trasforma note sparse, documenti o una semplice idea in una skill completa e
dettagliata per agenti AI. Poi la scarichi come `.md` o la pubblichi direttamente
su GitHub.

## Cosa fa

| Modalità | Input | Output |
| --- | --- | --- |
| **A. Da materiale esistente** | Fino a 20 file (`.md`, `.txt`, `.json`, codice) oppure testo incollato | Una skill unica che fonde tutto il materiale, colma i buchi e conserva i dettagli tecnici |
| **B. Da zero** | Wizard a 6 campi (nome, dominio, obiettivo, tono, vincoli, esempi) | Skill completa con procedura numerata, esempi, errori comuni, checklist |

Ogni skill generata ha questa struttura:

```
frontmatter YAML (name, description)
Quando usarla / Quando NON usarla
Prerequisiti
Procedura
Regole e vincoli
Esempi (input + output atteso)
Errori comuni
Checklist finale
```

## Stack

- **Next.js 16** (App Router, TypeScript)
- **NextAuth 4** con provider GitHub, scope `repo`
- **Token Harbor** come gateway AI, OpenAI-compatibile
- **Tailwind CSS 3** con palette calda in OKLCH
- Deploy su **Netlify** tramite `@netlify/plugin-nextjs`

## Avvio in locale

```bash
npm install
cp .env.example .env.local
# compila .env.local (vedi sotto)
npm run dev
```

Apri `http://localhost:3000`.

## Variabili d'ambiente

| Variabile | Dove trovarla |
| --- | --- |
| `GITHUB_ID` | [GitHub → Settings → Developer settings → OAuth Apps](https://github.com/settings/developers) |
| `GITHUB_SECRET` | Stessa pagina, dopo aver creato l'app |
| `NEXTAUTH_SECRET` | `openssl rand -base64 32` |
| `NEXTAUTH_URL` | `http://localhost:3000` in locale, l'URL Netlify in produzione |
| `TOKENHARBOR_BASE_URL` | `https://tokenharbor.ai/v1` |
| `TOKENHARBOR_API_KEY` | Dashboard Token Harbor, Universal Key `thk_live_...` |
| `TOKENHARBOR_MODEL` | `deepseek-v4.1-flash:free` |

### Creare la GitHub OAuth App

1. Vai su [github.com/settings/developers](https://github.com/settings/developers)
2. **New OAuth App**
3. **Homepage URL**: `http://localhost:3000`
4. **Authorization callback URL**: `http://localhost:3000/api/auth/callback/github`
5. Copia `Client ID` e `Client Secret` in `.env.local`

Per la produzione crea una **seconda** OAuth App (o aggiorna la callback) con:

```
https://<tuo-sito>.netlify.app/api/auth/callback/github
```

## Deploy su Netlify

### Via Git (consigliato)

1. Pusha il progetto su GitHub
2. Netlify → **Add new site** → **Import an existing project**
3. Scegli il repo. Netlify legge `netlify.toml` da solo
4. In **Site configuration → Environment variables** aggiungi tutte le
   variabili della tabella sopra, con `NEXTAUTH_URL` impostato all'URL finale
5. Deploy

### Via CLI

```bash
npm i -g netlify-cli
netlify login
netlify init
netlify env:set NEXTAUTH_SECRET "..."
netlify env:set GITHUB_ID "..."
netlify env:set GITHUB_SECRET "..."
netlify env:set TOKENHARBOR_API_KEY "..."
netlify deploy --prod
```

## Deploy automatico

Ogni push su `main` compila il progetto e pubblica su Netlify tramite
`.github/workflows/deploy.yml`. Setup una volta sola:

```bash
bash scripts/setup-deploy.sh
```

Lo script crea il repo GitHub, crea il sito Netlify e carica tutti i secret del
repository. Dettagli completi, inclusi i secret da impostare a mano, in
[docs/DEPLOY.md](docs/DEPLOY.md).

Flusso del workflow:

```
push su main  ->  job verify (npm ci + next build)  ->  job deploy (netlify deploy --prod)
```

Se la build fallisce, il deploy non parte e la produzione resta all'ultima
versione funzionante. Dal tab Actions puoi lanciarlo a mano in modalità preview.

## Struttura

```
.github/workflows/deploy.yml   verifica e deploy su Netlify
docs/DEPLOY.md                 guida completa al deploy automatico
scripts/setup-deploy.sh        onboarding: repo, sito, secret
scripts/check-env.mjs          controllo variabili prima del push
src/
├── app/
│   ├── page.tsx                     Landing con le due modalità
│   ├── create/from-skills/page.tsx  Modalità A
│   ├── create/from-scratch/page.tsx Modalità B
│   ├── dashboard/page.tsx           Dove finiscono le skill
│   └── api/
│       ├── auth/[...nextauth]/      NextAuth
│       ├── generate/                Chiamata al modello
│       └── publish/                 Commit su GitHub
├── components/
│   ├── Nav.tsx                      Header con login e menu utente
│   ├── CreateFlow.tsx               Form, risultato, download, publish
│   └── Providers.tsx                SessionProvider
└── lib/
    ├── ai.ts                        Client Token Harbor e system prompt
    ├── auth.ts                      Configurazione NextAuth
    ├── github.ts                    Wrapper API GitHub
    └── skill.ts                     Slug, fences, frontmatter
```

## Estensioni ovvie

- **Elenco skill in dashboard**: aggiungi `listFiles()` in `lib/github.ts` e una
  rotta `GET /api/skills` che legge `contents/skills` del repository
- **Streaming della generazione**: passa `stream: true` al modello e usa
  `ReadableStream` nel route handler
- **Versioning**: aggiorna le skill esistenti sfruttando lo SHA già gestito da
  `commitFile`
- **Template predefiniti**: catalogo di domini con prompt già compilati

## Licenza

Uso personale. Aggiungi una licenza se lo pubblichi.
