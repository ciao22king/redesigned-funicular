# Deploy automatico

Il workflow `.github/workflows/deploy.yml` pubblica il sito su Netlify a ogni
push su `main`. Nessun click, nessun token nel repository.

## Come funziona

```
push su main
   ↓
job "verify"   npm ci + next build   (fallisce qui se il codice è rotto)
   ↓
job "deploy"   netlify deploy --build --prod
   ↓
sito aggiornato
```

Se la build fallisce, il deploy **non parte**: il sito in produzione resta
all'ultima versione funzionante.

Puoi anche lanciarlo a mano: **Actions → Deploy su Netlify → Run workflow**.
Lì c'è una casella `production`: se la togli, ottieni un deploy preview (draft)
con URL temporaneo, senza toccare la produzione.

## Setup, una volta sola

### 1. Lo script

```bash
bash scripts/setup-deploy.sh
```

Ti chiede tre token e fa tutto: crea il repo GitHub, il sito Netlify, carica i
secret. Ti serve `gh` autenticato (`gh auth login`) per la parte dei secret.

### 2. Oppure a mano

**a.** Crea il sito Netlify e prendi il `Site ID`:
```
Site configuration → General → Site information → Site ID
```

**b.** Prendi il token Netlify:
```
app.netlify.com → User settings → Applications → Personal access tokens → New access token
```

**c.** Aggiungi i secret al repository GitHub:
```
Settings → Secrets and variables → Actions → New repository secret
```

| Secret | Valore |
| --- | --- |
| `NETLIFY_AUTH_TOKEN` | `uat_...` |
| `NETLIFY_SITE_ID` | l'ID del punto a |
| `NEXTAUTH_SECRET` | `openssl rand -base64 32` |
| `NEXTAUTH_URL` | `https://<sito>.netlify.app` |
| `GH_OAUTH_ID` | Client ID della OAuth App GitHub |
| `GH_OAUTH_SECRET` | Client Secret della OAuth App GitHub |
| `TOKENHARBOR_BASE_URL` | `https://tokenharbor.ai/v1` |
| `TOKENHARBOR_API_KEY` | `thk_live_...` |
| `TOKENHARBOR_MODEL` | `deepseek-v4.1-flash:free` |

**d.** Push su `main`.

## Perché i secret si chiamano `GH_OAUTH_ID` e non `GITHUB_ID`

`GITHUB_*` è riservato da GitHub Actions e non può essere sovrascritto con un
secret. Il workflow li rimappa:

```yaml
GITHUB_ID: ${{ secrets.GH_OAUTH_ID }}
GITHUB_SECRET: ${{ secrets.GH_OAUTH_SECRET }}
```

## La OAuth App GitHub

Anche con il deploy automatico, la OAuth App va creata a mano una volta:

1. [github.com/settings/developers](https://github.com/settings/developers) → **New OAuth App**
2. **Homepage URL**: `https://<sito>.netlify.app`
3. **Authorization callback URL**: `https://<sito>.netlify.app/api/auth/callback/github`
4. Copia Client ID e Secret nei secret `GH_OAUTH_ID` / `GH_OAUTH_SECRET`

Se vuoi che funzioni anche in locale, crea una seconda OAuth App puntata a
`http://localhost:3000`.

## Alternativa: integrazione nativa Netlify

Netlify sa collegarsi a GitHub da solo, senza workflow:

**Netlify → Site configuration → Build & deploy → Continuous deployment →
Link repository**

Differenza pratica: con l'integrazione nativa il deploy parte da Netlify, e le
variabili si gestiscono nella dashboard Netlify. Con il workflow hai in più il
job `verify` prima del deploy e la possibilità di lanciare preview manuali.
Scegli uno dei due, non entrambi, per non deployare due volte a ogni push.

## Se il deploy fallisce

| Sintomo | Causa |
| --- | --- |
| `NETLIFY_AUTH_TOKEN` mancante | secret non impostato, o nome sbagliato |
| `Site not found` | `NETLIFY_SITE_ID` di un altro sito |
| Build verde, sito bianco | manca `NEXTAUTH_URL` corretto |
| Login GitHub 404 | callback URL della OAuth App non corrisponde al dominio |
| Login funziona, publish fallisce | scope della OAuth App senza `repo` |